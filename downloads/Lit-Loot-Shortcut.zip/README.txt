Lit-Loot Shortcut Setup
=======================
Run Lit-Loot-Shortcut-Setup.exe. It asks whether to create a Desktop shortcut
and a Start Menu shortcut to https://azrloot.github.io/litloot/ with the Lit-Loot icon.
The icon is saved in %LOCALAPPDATA%\Lit-Loot. Nothing else is installed.
To remove: delete the Lit-Loot shortcuts and the %LOCALAPPDATA%\Lit-Loot folder.

Windows may show a SmartScreen warning because the exe is unsigned:
click "More info" > "Run anyway".
