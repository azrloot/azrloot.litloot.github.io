UninstallET 1.2
===============
Install: run UninstallET-Setup.exe. It asks whether to create a Desktop shortcut
and a Start Menu shortcut, then installs to Program Files.
UninstallET asks for admin when it runs - needed to remove system-wide programs.
To remove UninstallET itself, use Windows Settings > Apps, or its own list.

UNINSTALL page
- Tick any number of programs, then click "Uninstall selected".
- Uninstallers run one after another; the next starts when the previous finishes.
- "Silent when supported" removes MSI installs and apps with a quiet uninstall
  string without prompts. Others still show their own uninstaller.
- Anything still installed afterwards stays ticked so you can retry.
- Everything you remove is remembered on the Reinstall page.

REINSTALL page
- Lists every program you've uninstalled with this app (newest first).
- Before uninstalling, the app looks up each program's winget package ID.
  Programs with one are reinstalled automatically through winget
  (silently if "Silent when supported" is on).
- Programs not on winget open a download search in your browser instead.
- Successfully reinstalled programs drop off the list. "Remove from list"
  clears entries you don't want.
- History is saved in %APPDATA%\UninstallET\history.tsv

Other
- Search box filters the current page. Click column headers to sort.
- Double-click a row to toggle it. Right-click for more options.
- "Donate" opens the Lit-Loot donate page.

Windows may show a SmartScreen warning because the exe is unsigned:
click "More info" > "Run anyway".
