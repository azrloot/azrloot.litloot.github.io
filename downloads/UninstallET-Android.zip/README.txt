UninstallET for Android 1.0
===========================
Install: open UninstallET.apk on your phone and allow "install unknown apps"
when asked. If Play Protect warns, tap "Install anyway". Needs Android 5.0+.

- Uninstall page: tick apps, tap Uninstall. Android asks you to confirm each one.
- Reinstall page: apps you removed are remembered; tick them and tap Reinstall
  to open each one's store page in turn.
- Long-press any app for more options.
